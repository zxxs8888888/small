create definer = root@localhost trigger yx_cfq
    after insert
    on yx
    for each row
    insert into yx_time(time) values(now());

